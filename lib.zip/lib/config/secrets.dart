/* testign link*
class Secrets {
  static const supabaseUrl     = 'https://dyxcfmynjycfbancixhw.supabase.co';
  static const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR5eGNmbXluanljZmJhbmNpeGh3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwODEzMDAsImV4cCI6MjA5MTY1NzMwMH0.aQAD42r078yaUDMl66Dq6pZv94Xu1vlUeCSTG4g5o8s';
}
*/
class Secrets {
  static const supabaseUrl     = 'https://jbkbwqprwbkqoduwghjp.supabase.co';
  static const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impia2J3cXByd2JrcW9kdXdnaGpwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwMjc5NDgsImV4cCI6MjA4OTYwMzk0OH0.znNczDxJrxVV2aLI8jcg7hBuUF1CoyDk1fMUGXr7R_E';
}
